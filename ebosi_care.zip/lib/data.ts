export const allServices = [
  {
    id: "1",
    image: "/images/wheelchair_into_car.png",
    title: "Wheelchair",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    numOfPassangers: 1,
    numOfLuggages: 1,
  },
  {
    id: "2",
    image: "/images/stretcher.png",
    title: "Stretcher",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    numOfPassangers: 1,
    numOfLuggages: 1,
  },
  {
    id: "3",
    image: "/images/blue-sedan.png",
    title: "Sedan Ambulatory",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    numOfPassangers: 1,
    numOfLuggages: 1,
  },
  {
    id: "4",
    image: "/images/ambulance.png",
    title: "Medical Courier",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    numOfPassangers: 1,
    numOfLuggages: 1,
  },
  {
    id: "5",
    image: "/images/courier_transit.png",
    title: "Regular Delivery",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    numOfPassangers: 1,
    numOfLuggages: 1,
  },
  {
    id: "6",
    image: "/images/book_sitter.png",
    title: "Book a sitter",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    numOfPassangers: 1,
    numOfLuggages: 1,
  },
];

export const testimonials = [
  {
    id: "1",
    name: "John Doe",
    subname: "REGULAR CLIENT",
    image: "/images/avatar_.png",
    note: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua",
  },
  {
    id: "2",
    name: "John Doe",
    subname: "REGULAR CLIENT",
    image: "/images/avatar_.png",
    note: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua",
  },
  {
    id: "3",
    name: "John Doe",
    subname: "REGULAR CLIENT",
    image: "/images/avatar_.png",
    note: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua",
  },
];
